package com.example.sign_it_in

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
