## 1.0.5

- Fix MissingPluginException

## 1.0.4

- Annotate int with external in preparation of Flutter 2.5

## 1.0.3

- Add `buildSignature` to Android package info to retrieve the signing certifiate SHA1 at runtime.

## 1.0.2

- Remove trailing null characters

## 1.0.1

- Improve documentation

## 1.0.0

- Migrate to null-safety
- Update dependencies
- Fix dart SDK constraints

## [0.2.0]

- Use interface plugin 0.3.0

## [0.1.0]

- Initial version for Windows.
